﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RecipeMaster;
using RecipeMaster.Controllers;
using RecipeMaster.Repositories.EF;
using RecipeMaster.Models;

namespace RecipeMaster.Tests.Controllers
{
    [TestClass]
    public class HomeControllerTest
    {
        [TestMethod]
        public void Index()
        {
            //// Arrange
            var recipeMock = new Moq.Mock<IRecipeRepository>();
            recipeMock.Setup(x => x.GetAll()).Returns((new List<Recipe>()
            {
                new Recipe()
                {
                    Price = 12,
                    Description = "Pizza",
                    CreateBy ="Satish",
                    CreatedDate = DateTime.Now,
                    Image = "1",
                    Id = 1,
                    Name = "Pizza"
                }

            }).AsQueryable());

            HomeController controller = new HomeController(recipeMock.Object);

            //// Act
            ViewResult result = controller.Index() as ViewResult;
            var model = result.Model as IEnumerable<RecipeViewModel>;

            //// Assert
            Assert.IsTrue(model.Count() > 0);
        }

        [TestMethod]
        public void DetailsTest()
        {
            //// Arrange
            var recipeMock = new Moq.Mock<IRecipeRepository>();
            recipeMock.Setup(x => x.AllIncluding(y=>y.Ingredients)).Returns((new List<Recipe>()
            {
                new Recipe()
                {
                    Price = 12,
                    Description = "Pizza",
                    CreateBy ="Satish",
                    CreatedDate = DateTime.Now,
                    Image = "1",
                    Id = 1,
                    Name = "Pizza"
                }

            }).AsQueryable());
            HomeController controller = new HomeController(recipeMock.Object);

            //// Act
            ViewResult result = controller.Details(1) as ViewResult;
            var model = result.Model as RecipeViewModel;

            // Assert
            Assert.IsTrue(model.Id == 1);
        }      
    }
}
