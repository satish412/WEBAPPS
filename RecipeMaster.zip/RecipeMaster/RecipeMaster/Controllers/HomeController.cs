﻿using RecipeMaster.Models;
using RecipeMaster.Repositories.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RecipeMaster.Controllers
{

    public class HomeController : Controller
    {
        public IRecipeRepository _recRepo;


        public HomeController(IRecipeRepository recRepo)
        {
            _recRepo = recRepo;
        }

        public ActionResult Index()
        {
            var allRecipes = _recRepo.GetAll();

            List<RecipeViewModel> model = new List<RecipeViewModel>();

            foreach (var r in allRecipes)
            {
                model.Add(new RecipeViewModel()
                {
                    Price = r.Price,
                    Name = r.Name,
                    Description = r.Description,
                    Id = r.Id,
                    Image = r.Image,
                    CreatedBy = r.CreateBy,
                    CreatedDate = r.CreatedDate
                });
            }

            return View(model);
        }


        public ActionResult Details(int id)
        {
            var rec = _recRepo.AllIncluding(x => x.Ingredients).Where(x => x.Id == id).FirstOrDefault();

            RecipeViewModel vm = new RecipeViewModel();

            if (rec != null)
            {
                vm.Price = rec.Price;
                vm.Name = rec.Name;
                vm.Id = rec.Id;
                vm.Description = rec.Description;
                vm.CreatedBy = rec.CreateBy;
                vm.CreatedDate = rec.CreatedDate;
                vm.Ingredients = new List<IngredientViewModel>();

                foreach (var ing in rec.Ingredients)
                {
                    vm.Ingredients.Add(new IngredientViewModel()
                    {
                        IngredientName = ing.Name,
                        Quantity = ing.Quantity,
                        MeasurementName = ing.MeasureMent != null ? ing.MeasureMent.Name : string.Empty

                    });
                }
            }

            return View(vm);
        }


        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}