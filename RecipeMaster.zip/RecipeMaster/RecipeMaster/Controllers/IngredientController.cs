﻿using RecipeMaster.Models;
using RecipeMaster.Repositories.EF;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RecipeMaster.Controllers
{
    [Authorize]
    public class IngredientController : Controller
    {
        public IIngredientRepository _ingreRepo;
        public IMeasurementRepository _mesRepo;

        public IngredientController(IIngredientRepository ingreRepo, IMeasurementRepository mesRepo)
        {
            _ingreRepo = ingreRepo;
            _mesRepo = mesRepo;
        }

        // GET: Ingredient
        public ActionResult Index(int id, string Name)
        {
            var ingredients = _ingreRepo.AllIncluding(x => x.MeasureMent).Where(x => x.RecipeId == id);

            ViewBag.RecipeName = Name;
            ViewBag.RecipeId = id;

            var ingrVm = new List<IngredientViewModel>();

            foreach(var ing in ingredients)
            {
                ingrVm.Add(new IngredientViewModel()
                {
                    Id = ing.Id,
                    IngredientName = ing.Name,
                    Quantity = ing.Quantity,
                    MeasurementId = ing.MeasurementId,
                    RecipeId = ing.RecipeId,
                    MeasurementName = (ing.MeasureMent != null) ? ing.MeasureMent.Name : string.Empty
                });
            }

            return View(ingrVm);
        }


        // GET: Ingredient/Create
        public ActionResult Create(int RecipeId, string Name)
        {
            IngredientViewModel vm = new IngredientViewModel()
            {
                RecipeId = RecipeId                
            };

            ViewBag.Measurements = new SelectList(_mesRepo.GetAll().ToList(), "Id", "Name");
            ViewBag.RecipeName = Name;

            return View(vm);
        }

        // POST: Ingredient/Create
        [HttpPost]
        public ActionResult Create(IngredientViewModel ingVM, string RecipeName)
        {
            if(ModelState.IsValid)
            {
                Ingredient ig = new Ingredient()
                {
                    RecipeId = ingVM.RecipeId,
                    Name = ingVM.IngredientName,
                    MeasurementId = ingVM.MeasurementId,
                    Quantity = ingVM.Quantity
                };

                _ingreRepo.Add(ig);
                _ingreRepo.Save();

                return RedirectToAction("Index", new { id = ingVM.RecipeId, Name = RecipeName });
            }

            ViewBag.Measurements = new SelectList(_mesRepo.GetAll().ToList(), "Id", "Name");
            ViewBag.RecipeName = RecipeName;

            return View(ingVM);
        }

        // GET: Ingredient/Edit/5
        public ActionResult Edit(int id)
        {
            var ing = _ingreRepo.AllIncluding(x => x.Recipe).Where(x => x.Id == id).FirstOrDefault();

            IngredientViewModel vm = new IngredientViewModel();

            if (ing != null)
            {
                vm = new IngredientViewModel()
                {
                    RecipeId = ing.Recipe.Id,
                    Id = ing.Id,
                    IngredientName = ing.Name,
                    MeasurementId = ing.MeasurementId,
                    Quantity = ing.Quantity
                };

                ViewBag.RecipeName = ing.Recipe.Name;

            }

            ViewBag.Measurements = new SelectList(_mesRepo.GetAll().ToList(), "Id", "Name");

            return View(vm);
        }

        // POST: Ingredient/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, string RecipeName, IngredientViewModel vm)
        {
            if(ModelState.IsValid)
            {
                var ing = _ingreRepo.GetAll().Where(x => x.Id == id).FirstOrDefault();

                if(ing != null)
                {
                    ing.MeasurementId = vm.MeasurementId;
                    ing.Quantity = vm.Quantity;
                    ing.RecipeId = vm.RecipeId;
                    ing.Name = vm.IngredientName;

                    _ingreRepo.Edit(ing);
                    _ingreRepo.Save(); 
                }

                return RedirectToAction("Index", new { id = vm.RecipeId, Name = RecipeName });
            }

            ViewBag.RecipeName = RecipeName;
            ViewBag.Measurements = new SelectList(_mesRepo.GetAll().ToList(), "Id", "Name");

            return View(vm);
        }

        // GET: Ingredient/Delete/5
        public ActionResult Delete(int id)
        {
            var ing = _ingreRepo.AllIncluding(x => x.Recipe, y => y.MeasureMent).Where(x => x.Id == id).FirstOrDefault();

            IngredientViewModel vm = new IngredientViewModel();

            if (ing != null)
            {
                vm = new IngredientViewModel()
                {
                    RecipeId = ing.Recipe.Id,
                    Id = ing.Id,
                    IngredientName = ing.Name,
                    MeasurementId = ing.MeasurementId,
                    Quantity = ing.Quantity,
                    MeasurementName = ing.MeasureMent != null ? ing.MeasureMent.Name : string.Empty
                };

                ViewBag.RecipeName = ing.Recipe.Name;

            }

            return View(vm);
        }

        // POST: Ingredient/Delete/5
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteById(int id, string RecipeName)
        {
            ViewBag.RecipeName = RecipeName;

            try
            {
                var ing = _ingreRepo.AllIncluding(x => x.Recipe, y => y.MeasureMent).Where(x => x.Id == id).FirstOrDefault();

                if(ing != null)
                {
                    _ingreRepo.Delete(ing);
                    _ingreRepo.Save();
                }

                return RedirectToAction("Index", new { id = ing.RecipeId, Name = RecipeName });
            }
            catch
            {
                return View();
            }
        }
    }
}
