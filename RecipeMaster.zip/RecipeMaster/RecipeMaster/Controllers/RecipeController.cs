﻿using RecipeMaster.Models;
using RecipeMaster.Repositories.EF;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace RecipeMaster.Controllers
{
    [Authorize]
    public class RecipeController : Controller
    {

        private IRecipeRepository _recipeRepo;
        private IImageBlobRepository _imgRepo;

        public RecipeController(IRecipeRepository recipeRepo, IImageBlobRepository imgRepo)
        {
            _recipeRepo = recipeRepo;
            _imgRepo = imgRepo;
        }

        // GET: Recipe
        public ActionResult Index()
        {
            var allrecipes = _recipeRepo.GetAll().Where(x => x.CreateBy == this.User.Identity.Name);

            List<RecipeViewModel> model = new List<RecipeViewModel>();

            foreach (var r in allrecipes)
            {
                model.Add(new RecipeViewModel()
                {
                    Price = r.Price,
                    Name = r.Name,
                    Description = r.Description,
                    Id = r.Id,
                    Image = r.Image,
                    CreatedBy = r.CreateBy
                });
            }

            return View(model);
        }

        // GET: Recipe/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Recipe/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Recipe/Create
        [HttpPost]
        public ActionResult Create(RecipeViewModel model)
        {
            if (ModelState.IsValid)
            {
                Recipe r = new Recipe();
                r.Name = model.Name;
                r.Description = model.Description;
                r.Price = model.Price;
                r.CreateBy = this.User.Identity.Name;
                r.CreatedDate = DateTime.Now;

                if (model.file != null)
                {
                    // Azure not supporting save filing to disk. Seems we have to create storage.

                    //string newFileName = Guid.NewGuid().ToString() + Path.GetExtension(Path.GetFileName(model.file.FileName));
                    //string virtualPath = "~/RecipeImages/" + newFileName;
                    //model.file.SaveAs(Request.MapPath(virtualPath));
                    //r.Image = virtualPath;

                    int imageblobId = SaveImage(model.file);
                    if(imageblobId > 0)
                    r.Image = imageblobId.ToString();
                    
                }

                _recipeRepo.Add(r);
                _recipeRepo.Save();

                return RedirectToAction("Index");
            }
            return View(model);
        }

        private int SaveImage(HttpPostedFileBase file)
        {
            string filePath = file.FileName;
            string filename = Path.GetFileName(filePath);
            string ext = Path.GetExtension(filename);
            string contenttype = String.Empty;

            contenttype = System.Web.MimeMapping.GetMimeMapping(filename);

            if (contenttype != String.Empty)
            {

                Stream fs = file.InputStream;
                BinaryReader br = new BinaryReader(fs);
                Byte[] bytes = br.ReadBytes((Int32)fs.Length);

                ImageBlob image = new ImageBlob();

                image.Name = filename;
                image.ContentType = contenttype;
                image.ContentLength = file.ContentLength.ToString();
                image.Extension = ext;
                image.BlobData = bytes;

                _imgRepo.Add(image);
                _imgRepo.Save();

                return image.ID;
            }

            return 0;
        }

        private void UpdateImage(HttpPostedFileBase file, int blobId)
        {
            string filePath = file.FileName;
            string filename = Path.GetFileName(filePath);
            string ext = Path.GetExtension(filename);
            string contenttype = String.Empty;

            contenttype = System.Web.MimeMapping.GetMimeMapping(filename);

            if (contenttype != String.Empty)
            {

                Stream fs = file.InputStream;
                BinaryReader br = new BinaryReader(fs);
                Byte[] bytes = br.ReadBytes((Int32)fs.Length);

                ImageBlob image = _imgRepo.GetAll().Where(x => x.ID == blobId).FirstOrDefault();

                if (image != null)
                {
                    image.Name = filename;
                    image.ContentType = contenttype;
                    image.ContentLength = file.ContentLength.ToString();
                    image.Extension = ext;
                    image.BlobData = bytes;

                    _imgRepo.Edit(image);
                    _imgRepo.Save();
                }

            }

        }




        // GET: Recipe/Edit/5
        public ActionResult Edit(int id)
        {
            var recipe = _recipeRepo.GetAll().Where(x => x.Id == id).FirstOrDefault();

            RecipeViewModel editVm = new RecipeViewModel();

            if (recipe != null)
            {
                editVm.Price = recipe.Price;
                editVm.Name = recipe.Name;
                editVm.Description = recipe.Description;
            }

            return View(editVm);
        }

        // POST: Recipe/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, RecipeViewModel editVm)
        {
            if (ModelState.IsValid)
            {
                var recipe = _recipeRepo.GetAll().Where(x => x.Id == id).FirstOrDefault();

                if (recipe != null)
                {
                    recipe.Name = editVm.Name;
                    recipe.Description = editVm.Description;
                    recipe.Price = editVm.Price;

                    if (editVm.file != null && !string.IsNullOrEmpty(recipe.Image))
                    {
                        UpdateImage(editVm.file, Convert.ToInt32(recipe.Image));
                    }

                    _recipeRepo.Edit(recipe);
                    _recipeRepo.Save();
                }

                return RedirectToAction("Index");
            }

            return View(editVm);
        }

        [AllowAnonymous]
        public ActionResult ViewImage(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            var image = _imgRepo.GetAll().Where(x => x.ID == id).FirstOrDefault();

            if (image != null && image.BlobData != null)
            {
                var cd = new System.Net.Mime.ContentDisposition { FileName = image.Name, Inline = false };

                byte[] Data = (byte[])image.BlobData.ToArray();
                Response.AppendHeader("Content-Disposition", cd.ToString());
                return File(Data, image.ContentType);
            }
            else
            {
                return View();
            }
        }

        // GET: Recipe/Delete/5
        public ActionResult Delete(int id)
        {
            var recipe = _recipeRepo.GetAll().Where(x => x.Id == id).FirstOrDefault();

            RecipeViewModel editVm = new RecipeViewModel();

            if (recipe != null)
            {
                editVm.Price = recipe.Price;
                editVm.Name = recipe.Name;
                editVm.Description = recipe.Description;
            }

            return View(editVm);
        }

        // POST: Recipe/Delete/5
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteById(int id)
        {
            var recipe = _recipeRepo.GetAll().Where(x => x.Id == id).FirstOrDefault();

            if (recipe != null)
            {
                _recipeRepo.Delete(recipe);
                _recipeRepo.Save();
            }

            return RedirectToAction("Index");

        }
    }
}
