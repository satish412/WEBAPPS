﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace RecipeMaster.Models
{
    public class IngredientViewModel : IValidatableObject
    {
        public int Id { get; set; }

        [Required]
        public string IngredientName { get; set; }

        public Nullable<int> Quantity { get; set; }
        public Nullable<int> MeasurementId { get; set; }

        [Required]
        public int RecipeId { get; set; }

        public string MeasurementName { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (this.Quantity.HasValue && this.Quantity.Value > 0 && (!this.MeasurementId.HasValue || this.MeasurementId.Value == 0))
            {
                yield return new ValidationResult("Measurement should be entered when quantity is entered.", new[] { "MeasurementId" });
            }

            if (this.MeasurementId.HasValue && this.MeasurementId.Value > 0 && (!this.Quantity.HasValue || this.Quantity.Value == 0))
            {
                yield return new ValidationResult("Quantity should be entered when Measurement is entered.", new[] { "Quantity" });
            }
        }
    }
}