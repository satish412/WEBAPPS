﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace RecipeMaster.Models
{
    public class RecipeViewModel : IValidatableObject
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string Description { get; set; }

        public string Image { get; set; }

        [DataType(DataType.Upload)]
        [Display(Name = "Image")]
        public HttpPostedFileBase file { get; set; }

        [Required]
        public decimal Price { get; set; }

        public DateTime? CreatedDate { get; set; }

        public string CreatedBy { get; set; }

        public List<IngredientViewModel> Ingredients { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (this.Id == 0 && this.file == null)
            {
                yield return new ValidationResult("Image field is required.", new[] { "file" });
            }
        }

    }
}